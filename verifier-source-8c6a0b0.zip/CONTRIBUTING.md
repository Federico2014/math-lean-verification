# Adding candidates and contributing

Use English for repository content, issues and PRs. Preserve mathematical notation
and original names for attribution. Registration and CI results do not decide awards.

## Submit a candidate

1. Copy [the candidate template](templates/candidate.json) to
   `candidates/<candidate-id>.json` and complete its fields. Supply a fixed public
   proof commit, all target modules/declarations, problem ID or original problem
   description, author/AI attribution, assumptions and publication permission.
2. Open one PR per candidate targeting `main`. An Issue and local Lean execution are optional;
   CI computes source hashes, selects approved configuration and prepares the bridge.
3. Inspect the trusted CI plan and proof evidence. Update your PR if materials or
   proofs need correction. When configuration is pending, keep the PR open.

A new problem description uses `problem: {"title": "…", "source_url": "https://…",
"scope": "…"}` instead of `problem_id`. A maintainer must map it to an approved
statement. A similar title alone cannot establish mathematical correspondence.

For unusual layouts, set `source.project_root` or an explicit source selection.
If automatic bridging is ambiguous, supply `bridge: "Bridge.lean"` and place the
file at `proofs/<candidate-id>/Bridge.lean`. This is untrusted proof code subject
to all normal checks. See [intake operations](docs/simplified-intake.md).

## Maintainer responsibilities

Prepare new workspaces, review correspondence, and onboard environments in separate
maintenance PRs. Follow [statement review](docs/statement-review.md) and
[environment onboarding](docs/environment-onboarding.md). Required evidence and
policy approval are mandatory; draft generation and onboarding tests do not approve
anything automatically. Protect exceptional mappings in `intake-mappings/`.

Once those changes reach main, the scheduler rechecks open PRs and dispatches ready
ones automatically. It does not run Lean while prerequisites are missing. Resolve
any proof failures with the author. Merge only after exact statement approval and
all required `registry`, `tests`, `lean-verification` checks pass. Protect the
required status against unrelated writers using repository settings.

Merging registers the candidate and starts main revalidation. The generated
[Registered candidates page](https://Federico2014.github.io/math-lean-verification/)
updates automatically; do not maintain result rows by hand.

## Repository implementation changes

Read `AGENTS.md`, `README.md`, `SECURITY.md`, `docs/design.md` and
`docs/implementation-status.md` before changing the verifier. Use Python 3.12 and run:

```bash
python -m unittest discover -s tests -v
python -m verifier validate
```

Describe changed behavior and test evidence in the PR. Link related issues when
applicable. Never execute candidate Lean or Lake on the host. Backend CI runs real
positive and adversarial proof cases in isolated containers; tests with a fake
checker do not establish proof validity or production event-chain acceptance.
