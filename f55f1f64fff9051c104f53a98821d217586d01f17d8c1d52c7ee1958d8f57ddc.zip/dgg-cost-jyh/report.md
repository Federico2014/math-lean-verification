# Lean verification report

```json
{
  "submission_id": "dgg-cost-jyh",
  "verification_status": "verified",
  "machine_status": "passed",
  "review_status": "approved",
  "review_approval_kind": "administrator_exception",
  "review_administrator": "Federico2014",
  "formal_status": "pending",
  "bindings": {
    "pr_head": "ea41d0d948f0493b6772138833c208a94383566e",
    "base_sha": "8c6a0b0e21fdc63536351fb934e1f66e9fc3b877",
    "upstream_commit": "ffba3523f0edd14be3460d039f22a6b98c02fd9e",
    "workspace_digest": "38980c8a307755339b8ccbea0ebc8645070a5c56bd6223e7d758d7f879deb2eb",
    "environment_digest": "2549518f7e642162f4a05d3c1b0eedd6c3fc0a4431f5b40b4bbc7da9abfd1396",
    "policy_digest": "d32d5cc061496e704e3ada6a0e24b78d97b0b6eac3dc4f43e3c8b53b0a0074ed",
    "run_id": "34466489912",
    "run_attempt": "1"
  },
  "required_theorems": [
    "OfficialDGG.goemans_cost_conjecture_false"
  ],
  "candidate_targets": [
    "Submission.goemans_cost_conjecture_false"
  ],
  "error": null
}
```

This report does not grant formal acceptance or decide award eligibility.

See result.json and execution-*.json for stage outcomes. The controller records
aggregate target checks; per-theorem axiom inventories are not yet available.
